#!/usr/bin/env python3
"""On-robot Nav2 stack supervisor and one-shot pick/return FSM.

Uploaded by execute_robot.py. ROS uses system Python; arm_cli uses arm-venv.
"""
import argparse
import fcntl
import json
import math
import os
from pathlib import Path
import queue
import signal
import subprocess
import sys
import threading
import time

PREFIX = '@@ROBOT_EVENT@@'
COLORS = {'red', 'orange', 'yellow', 'green', 'blue', 'purple'}


def event(kind, **fields):
    print(PREFIX + json.dumps({'event': kind, **fields}, ensure_ascii=False), flush=True)


def last_json(output):
    for line in reversed(output.splitlines()):
        try:
            value = json.loads(line)
            if isinstance(value, dict):
                return value
        except ValueError:
            pass
    raise RuntimeError('명령의 JSON 결과가 없습니다: ' + output[-500:])


def validate_point(point):
    if not isinstance(point, dict) or point.get('frame_id') != 'map':
        raise ValueError('waypoint는 frame_id: map이어야 합니다.')
    for key in ('x', 'y', 'yaw'):
        value = point.get(key)
        if type(value) not in (int, float) or not math.isfinite(value):
            raise ValueError(f'waypoint {key}에 유한한 숫자가 필요합니다.')
    return {key: point[key] for key in ('frame_id', 'x', 'y', 'yaw')}


def validate_request(request):
    if request.get('color') not in COLORS:
        raise ValueError('지원하지 않는 블록 색상입니다.')
    validate_point(request['destination'])
    if request.get('start') != 'current':
        validate_point(request['start'])
    return request


def stop_group(process, graces=(8, 3, 1)):
    for sig, grace in zip((signal.SIGINT, signal.SIGTERM, signal.SIGKILL), graces):
        try:
            os.killpg(process.pid, sig)
        except ProcessLookupError:
            break
        deadline = time.monotonic() + grace
        while time.monotonic() < deadline:
            process.poll()
            try:
                os.killpg(process.pid, 0)
            except ProcessLookupError:
                break
            time.sleep(.1)
        else:
            continue
        break
    process.wait()


class Control:
    def __init__(self):
        self.last = time.monotonic()
        self.lost = threading.Event()
        self.messages = queue.Queue()
        threading.Thread(target=self.read, daemon=True).start()

    def read(self):
        for line in sys.stdin:
            try:
                message = json.loads(line)
                if message.get('type') == 'heartbeat':
                    self.last = time.monotonic()
                elif message.get('type') == 'stop':
                    self.lost.set()
                    return
                elif message.get('type') == 'mission':
                    self.messages.put(message['request'])
            except (ValueError, KeyError, AttributeError):
                self.lost.set()
                return
        self.lost.set()

    def check(self):
        if self.lost.is_set() or time.monotonic() - self.last > 15:
            raise RuntimeError('노트북 제어 연결/heartbeat 종료')


class Processes:
    def __init__(self, directory, control=None):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.entries = []
        self.control = control

    def start(self, name, argv, persistent=True):
        path = self.directory / (name + '.log')
        log = path.open('wb')
        try:
            process = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=log,
                                       stderr=subprocess.STDOUT, start_new_session=True)
        except BaseException:
            log.close()
            raise
        self.entries.append((name, process, log, path, persistent))
        return process, path

    def check(self):
        if self.control:
            self.control.check()
        for name, process, _, path, persistent in self.entries:
            if persistent and process.poll() is not None:
                raise RuntimeError(f'{name} 종료({process.returncode}): '
                                   + path.read_text(errors='replace')[-3000:])

    def run(self, name, argv, timeout):
        process, path = self.start(name, argv, persistent=False)
        deadline = time.monotonic() + timeout
        offset, partial = 0, ''

        def forward():
            nonlocal offset, partial
            with path.open(errors='replace') as stream:
                stream.seek(offset)
                chunk = stream.read()
                offset = stream.tell()
            lines = (partial + chunk).split('\n')
            partial = lines.pop()
            for line in lines:
                if line.startswith(PREFIX):
                    print(line, flush=True)

        while process.poll() is None:
            forward()
            self.check()
            if time.monotonic() > deadline:
                raise RuntimeError(f'{name} 시간 초과')
            time.sleep(.1)
        forward()
        output = path.read_text(errors='replace')
        if process.returncode:
            raise RuntimeError(f'{name} 실패({process.returncode}): {output[-3000:]}')
        return output

    def close(self):
        for _, process, log, _, _ in reversed(self.entries):
            stop_group(process)
            log.close()


def dependencies(config):
    import yaml
    import rclpy
    from ament_index_python.packages import get_package_share_directory
    for name in ('nav2_bringup', 'nav2_simple_commander', 'turtlebot3_bringup'):
        get_package_share_directory(name)
    for key in ('map', 'params_file', 'arm_python', 'arm_cli'):
        if not Path(config[key]).is_file():
            raise RuntimeError(f'{key} 파일 없음: {config[key]}')
    path = Path(config['map'])
    image = Path(yaml.safe_load(path.read_text())['image'])
    if not image.is_absolute():
        image = path.parent / image
    if not image.is_file():
        raise RuntimeError(f'지도 이미지 없음: {image}')
    root = Path(config['arm_cli']).parent
    for name in ('park_pose.json', 'carry_pose.json', 'look_pose.json', 'wrist_camera.json'):
        if not (root / 'calibration' / name).is_file():
            raise RuntimeError(f'팔 보정/자세 파일 없음: {name}')
    if config.get('place_on_return') and not (root / 'calibration/place_pose.json').is_file():
        raise RuntimeError('place_pose.json이 필요합니다.')
    completed = subprocess.run([config['arm_python'], '-c',
        'import scipy, numpy; import robot.tasks; from vision.camera import COLOR_RANGES; '
        'print(sorted(COLOR_RANGES))'], cwd=root, capture_output=True, text=True, timeout=40)
    if completed.returncode:
        raise RuntimeError('팔 가상환경 의존성: ' + completed.stderr[-2000:])
    event('checked', model=os.getenv('TURTLEBOT3_MODEL'),
          domain=os.getenv('ROS_DOMAIN_ID'), arm_colors=completed.stdout.strip())


def ros_probe(kind, timeout):
    import rclpy
    from rclpy.signals import SignalHandlerOptions
    from sensor_msgs.msg import LaserScan
    from nav_msgs.msg import Odometry, OccupancyGrid
    from rclpy.qos import qos_profile_sensor_data, QoSProfile, DurabilityPolicy
    from tf2_ros import Buffer, TransformListener, TransformException
    from lifecycle_msgs.srv import GetState
    rclpy.init(signal_handler_options=SignalHandlerOptions.NO)
    node = rclpy.create_node('mission_probe_' + str(os.getpid()))
    seen, active, pending, subscriptions = set(), set(), {}, []
    buffer = Buffer()
    listener = TransformListener(buffer, node)
    for topic, msgtype in (('/scan', LaserScan), ('/odom', Odometry)):
        subscriptions.append(node.create_subscription(msgtype, topic,
            lambda msg, t=topic: seen.add(t), qos_profile_sensor_data))
    subscriptions.append(node.create_subscription(OccupancyGrid, '/map',
        lambda msg: seen.add('/map'), QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL)))
    names = ('map_server', 'amcl', 'planner_server', 'controller_server', 'bt_navigator')
    clients = {name: node.create_client(GetState, '/' + name + '/get_state') for name in names}
    start = time.monotonic()
    try:
        while time.monotonic() - start < timeout:
            rclpy.spin_once(node, timeout_sec=.1)
            if kind == 'graph':
                if time.monotonic() - start > 3:
                    print(json.dumps(sorted(set(node.get_node_names()))), flush=True)
                    return
                continue
            if kind == 'bringup':
                if not {'/scan', '/odom'} <= seen:
                    continue
                try:
                    buffer.lookup_transform('odom', 'base_link', rclpy.time.Time())
                except TransformException:
                    continue
                event('bringup_ready')
                return
            for name, client in clients.items():
                if name in active:
                    continue
                future = pending.get(name)
                if future is not None:
                    if future.done():
                        result = future.result()
                        if result and result.current_state.id == 3:
                            active.add(name)
                        del pending[name]
                elif client.service_is_ready():
                    pending[name] = client.call_async(GetState.Request())
            if active == set(names) and '/map' in seen:
                return
        raise RuntimeError(f'{kind} 준비 시간 초과: topics={sorted(seen)}, active={sorted(active)}')
    finally:
        node.destroy_node()
        rclpy.shutdown()


def run_stack(config, config_path):
    lock = (Path(config_path).parent.parent / 'stack.lock').open('w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    control = Control()
    processes = Processes(config['logs'], control)
    script = str(Path(__file__).resolve())
    helper = lambda kind: ['/usr/bin/python3', '-u', script, '--mode', 'probe',
                          '--kind', kind, '--timeout', str(config['timeout'])]
    try:
        dependencies(config)
        names = json.loads(processes.run('graph', helper('graph'), 15).strip().splitlines()[-1])
        bringup = {'turtlebot3_node', 'robot_state_publisher', 'lidar_node', 'diff_drive_controller'}
        nav2 = {'map_server', 'amcl', 'planner_server', 'controller_server', 'bt_navigator'}
        if bringup.intersection(names) and not config['reuse_bringup']:
            raise RuntimeError('기존 bringup을 종료하거나 --reuse-bringup 사용')
        if nav2.intersection(names) and not config['reuse_nav2']:
            raise RuntimeError('기존 Nav2(노트북 포함)를 종료하세요. 파이 Nav2만 재사용하려면 --reuse-nav2 사용')
        if config['reuse_nav2']:
            # ROS discovery cannot tell which host owns a node. Verify a local
            # Nav2 process instead of silently reusing an old laptop Nav2 stack.
            command = subprocess.check_output(['ps', '-eo', 'args'], text=True)
            if not any(marker in command for marker in
                       ('nav2_container', 'nav2_map_server/map_server', 'nav2_amcl/amcl')):
                raise RuntimeError('--reuse-nav2: 파이 내부 Nav2 프로세스를 찾지 못했습니다.')
        if not config['reuse_bringup']:
            processes.start('bringup', ['ros2', 'launch', 'turtlebot3_bringup',
                                      'robot.launch.py', 'use_sim_time:=false'])
        processes.run('bringup-ready', helper('bringup'), config['timeout'] + 10)
        if not config['reuse_nav2']:
            processes.start('nav2', ['ros2', 'launch', 'nav2_bringup', 'bringup_launch.py',
                'map:=' + config['map'], 'params_file:=' + config['params_file'],
                'use_sim_time:=false', 'autostart:=true', 'use_composition:=true'])
        processes.run('nav2-ready', helper('nav2'), config['timeout'] + 10)
        event('ready', logs=config['logs'])
        while True:
            processes.check()
            try:
                request = control.messages.get(timeout=.2)
            except queue.Empty:
                continue
            validate_request(request)
            request_file = Path(config_path).with_name('mission.json')
            request_file.write_text(json.dumps(request, ensure_ascii=False))
            processes.run('mission', ['/usr/bin/python3', '-u', script, '--mode', 'mission',
                '--config', str(config_path), '--request', str(request_file)],
                config['nav_timeout'] * 2 + config['arm_timeout'] *
                (4 if config.get('place_on_return') else 3) + config['timeout'] + 60)
            event('mission_done')
            return
    except BaseException as exc:
        event('error', message=str(exc) or type(exc).__name__)
        raise
    finally:
        processes.close()
        lock.close()
        event('stack_stopped')


class Mission:
    def __init__(self, config):
        import rclpy
        from rclpy.signals import SignalHandlerOptions
        from nav2_simple_commander.robot_navigator import BasicNavigator
        from nav_msgs.msg import Odometry
        from geometry_msgs.msg import Twist
        from rclpy.qos import qos_profile_sensor_data
        from tf2_ros import Buffer, TransformListener
        self.config = config
        self.rclpy = rclpy
        rclpy.init(signal_handler_options=SignalHandlerOptions.NO)
        self.nav = BasicNavigator()
        self.buffer = Buffer()
        self.listener = TransformListener(self.buffer, self.nav)
        self.odom = None
        self.subscription = self.nav.create_subscription(Odometry, '/odom', self.on_odom,
                                                         qos_profile_sensor_data)
        self.velocity = self.nav.create_publisher(Twist, '/cmd_vel', 10)
        self.moving = False
        self.arm_process = None
        self.log_root = Path(config['logs'])

    def on_odom(self, msg):
        self.odom = (msg, time.monotonic())

    def pose(self):
        from tf2_ros import TransformException
        try:
            tf = self.buffer.lookup_transform('map', 'base_link', self.rclpy.time.Time())
        except TransformException:
            return None
        stamp = tf.header.stamp.sec + tf.header.stamp.nanosec / 1e9
        age = self.nav.get_clock().now().nanoseconds / 1e9 - stamp
        if not -2 < age < 2:
            return None
        t, q = tf.transform.translation, tf.transform.rotation
        return {'frame_id': 'map', 'x': t.x, 'y': t.y,
                'yaw': math.atan2(2 * (q.w*q.z + q.x*q.y), 1 - 2*(q.y*q.y + q.z*q.z))}

    def localize(self):
        event('state', state='LOCALIZING', message='RViz 2D Pose Estimate로 초기 위치를 지정하세요.')
        deadline = time.monotonic() + self.config['timeout']
        while time.monotonic() < deadline:
            self.rclpy.spin_once(self.nav, timeout_sec=.1)
            pose = self.pose()
            if pose:
                return pose
        raise RuntimeError('map -> base_link 없음/오래됨. 초기 위치·AMCL·TF·시간 확인')

    def stop_base(self):
        from geometry_msgs.msg import Twist
        for _ in range(5):
            self.velocity.publish(Twist())
            self.rclpy.spin_once(self.nav, timeout_sec=.05)

    def stationary(self):
        self.stop_base()
        deadline, stable = time.monotonic() + 10, None
        while time.monotonic() < deadline:
            self.rclpy.spin_once(self.nav, timeout_sec=.1)
            now = time.monotonic()
            valid = False
            if self.odom:
                msg, received = self.odom
                stamp = msg.header.stamp.sec + msg.header.stamp.nanosec / 1e9
                age = self.nav.get_clock().now().nanoseconds / 1e9 - stamp
                v = msg.twist.twist
                valid = (now - received < 1 and -.5 < age < 1.5 and
                         math.hypot(v.linear.x, v.linear.y) < .01 and abs(v.angular.z) < .03)
            stable = (stable if stable is not None else now) if valid else None
            if stable is not None and now - stable >= 1:
                return
        raise RuntimeError('베이스 정지 확인 실패: /odom 속도/시각 확인')

    def navigate(self, point, state):
        from geometry_msgs.msg import PoseStamped
        from nav2_simple_commander.robot_navigator import TaskResult
        event('state', state=state, goal=point)
        goal = PoseStamped()
        goal.header.frame_id = 'map'
        goal.header.stamp = self.nav.get_clock().now().to_msg()
        goal.pose.position.x, goal.pose.position.y = float(point['x']), float(point['y'])
        goal.pose.orientation.z = math.sin(point['yaw'] / 2)
        goal.pose.orientation.w = math.cos(point['yaw'] / 2)
        self.moving = True
        if self.nav.goToPose(goal) is False:
            raise RuntimeError('Nav2가 이동 목표를 거절했습니다.')
        deadline = time.monotonic() + self.config['nav_timeout']
        while not self.nav.isTaskComplete():
            if time.monotonic() > deadline:
                raise RuntimeError('Nav2 이동 시간 초과')
        self.moving = False
        result = self.nav.getResult()
        if result != TaskResult.SUCCEEDED:
            raise RuntimeError('Nav2 이동 실패: ' + result.name)
        self.stationary()
        actual = self.pose()
        if actual is None:
            raise RuntimeError('도착 후 map TF 없음')
        distance = math.hypot(actual['x'] - point['x'], actual['y'] - point['y'])
        angle = abs(math.atan2(math.sin(actual['yaw'] - point['yaw']),
                               math.cos(actual['yaw'] - point['yaw'])))
        if distance > .15 or angle > .15:
            raise RuntimeError(f'도착 자세 오차 초과: {distance:.3f}m, {math.degrees(angle):.1f}도')
        event('arrived', distance_error_m=distance, yaw_error_rad=angle)

    def arm(self, command, color=None):
        # Convert cancellation into ArmStop INSIDE arm_cli.run. Its error path
        # holds torque and detaches, unlike an unhandled KeyboardInterrupt that
        # could enter the normal shutdown/park path. Do not modify arm_cli.py.
        bridge = ('import signal\nfrom robot.arm import ArmStop\n'
                  'def stop(signum, frame):\n    raise ArmStop("작업 제어기 취소 요청")\n'
                  'signal.signal(signal.SIGINT, stop)\n'
                  'signal.signal(signal.SIGTERM, stop)\n'
                  'import arm_cli\narm_cli.main()\n')
        argv = [self.config['arm_python'], '-u', '-c', bridge, command]
        if color:
            argv += ['--color', color]
        path = self.log_root / ('arm-' + command + '.log')
        with tempfile_output() as output, path.open('wb') as error:
            self.arm_process = subprocess.Popen(argv, cwd=Path(self.config['arm_cli']).parent,
                stdin=subprocess.DEVNULL, stdout=output, stderr=error, start_new_session=True)
            deadline = time.monotonic() + self.config['arm_timeout']
            while self.arm_process.poll() is None:
                self.rclpy.spin_once(self.nav, timeout_sec=.1)
                # Interrupt any arm command if fresh odometry reports base motion.
                if self.odom and time.monotonic() - self.odom[1] < 1:
                    v = self.odom[0].twist.twist
                    if math.hypot(v.linear.x, v.linear.y) > .02 or abs(v.angular.z) > .05:
                        raise RuntimeError('팔 작업 중 베이스 움직임 감지')
                elif self.odom is None or time.monotonic() - self.odom[1] > 2:
                    raise RuntimeError('팔 작업 중 오도메트리 수신 중단')
                if time.monotonic() > deadline:
                    raise RuntimeError('팔 명령 시간 초과: ' + command)
            code = self.arm_process.returncode
            self.arm_process = None
            output.seek(0)
            result = last_json(output.read().decode(errors='replace'))
        event('arm_result', command=command, result=result)
        if code or result.get('ok') is not True:
            raise RuntimeError(f'팔 {command} 실패: {result}')
        if command == 'pick' and (result.get('result') != 'picked' or
                result.get('holding') is not True or result.get('pose') != 'carry'):
            raise RuntimeError('집기 성공·운반 자세 확인 실패')
        expected = {'place': 'placed', 'park': 'parked', 'status': 'status'}
        if command in expected and result.get('result') != expected[command]:
            raise RuntimeError('예상과 다른 팔 결과: ' + str(result))
        if command == 'place' and (result.get('holding') is not False or result.get('pose') != 'park'):
            raise RuntimeError('내려놓기·팔 접기 결과 확인 실패: ' + str(result))
        return result

    def run(self, request):
        validate_request(request)
        current = self.localize()
        start = current if request['start'] == 'current' else request['start']
        event('state', state='PREPARING', return_goal=start)
        self.stationary()
        status = self.arm('status')
        if status.get('holding'):
            raise RuntimeError('팔이 이미 블록을 보유 중입니다. 기존 작업을 먼저 확인하세요.')
        self.arm('park')
        self.navigate(request['destination'], 'NAVIGATING_TO_PICK')
        event('state', state='PICKING', color=request['color'])
        self.arm('pick', request['color'])
        self.navigate(start, 'RETURNING')
        if self.config.get('place_on_return'):
            event('state', state='PLACING')
            self.arm('place')
        event('state', state='DONE', holding=not self.config.get('place_on_return', False))

    def close(self):
        try:
            # The arm has its own process group. Stop it FIRST, within the
            # supervisor's grace period, so forced worker termination cannot
            # leave an arm command running independently.
            if self.arm_process:
                stop_group(self.arm_process, graces=(3, 1, 1))
        finally:
            try:
                if self.moving:
                    self.nav.cancelTask()
                self.stop_base()
            finally:
                self.nav.destroy_node()
                self.rclpy.shutdown()


def tempfile_output():
    import tempfile
    return tempfile.TemporaryFile()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=['stack', 'check', 'probe', 'mission'], required=True)
    parser.add_argument('--config', type=Path)
    parser.add_argument('--request', type=Path)
    parser.add_argument('--kind', choices=['graph', 'bringup', 'nav2'])
    parser.add_argument('--timeout', type=float, default=120)
    args = parser.parse_args()
    if args.mode == 'probe':
        ros_probe(args.kind, args.timeout)
        return
    config = json.loads(args.config.read_text())
    if args.mode == 'check':
        dependencies(config)
    elif args.mode == 'stack':
        run_stack(config, args.config)
    else:
        # Take the project-wide arm lock only inside arm_cli; never share its bus.
        mission = Mission(config)
        try:
            mission.run(json.loads(args.request.read_text()))
        except BaseException as exc:
            event('state', state='ERROR', message=str(exc) or type(exc).__name__)
            raise
        finally:
            mission.close()


if __name__ == '__main__':
    stop_requested = False
    def interrupted(signum, frame):
        global stop_requested
        if stop_requested:
            return
        stop_requested = True
        raise KeyboardInterrupt
    signal.signal(signal.SIGINT, interrupted)
    signal.signal(signal.SIGTERM, interrupted)
    try:
        main()
    except KeyboardInterrupt:
        raise SystemExit(130)
    except Exception as exc:
        event('error', message=str(exc))
        raise SystemExit(1)
